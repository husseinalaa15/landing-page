/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
 * 
*/


// get all sections and navbar menu

const sections = document.getElementsByTagName('section');
const menu = document.getElementById('navbar__list');

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/

// check if element in view 

function sectionInView(el){
    const rect = el.getBoundingClientRect();
    console.log(rect);
    return(
        rect.top >= -400 
        && 
        rect.top <= 150

        )
}


/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/
// here im looping on section to put every section in an its li inside menu or navbar
function createMenu(){
    for(section of sections){
        let sectionId = section.id;
        let sectionDataNav = section.getAttribute('data-nav');
    
        let LiItems = document.createElement('li');
        LiItems.innerHTML = `<a class="menu__link" href="#${sectionId}">${sectionDataNav}</a>`;
        menu.appendChild(LiItems);
    }
    const menuAnchor = document.querySelectorAll("#navbar__list a");
    
    menuAnchor.forEach((link) => {
    
        link.addEventListener('click', (e) => {
            e.preventDefault();  // prevent the page from reloading (a default behavior when a link is clicked)
            const id = e.target.hash;
            // console.log(id);
            // // get the reference to the corresponding section
            const targetSection = document.querySelector(id) // use `.querySelector(id)` to select the corresponding section
            // console.log(targetSection);
            // add smooth scrolling feature like this-
            targetSection.scrollIntoView({
                behavior: "smooth",
                block: "end",
                inline: "nearest",
            });
            
        })
    });
    
    
}

createMenu();




/**
 * End Main Functions
 * Begin Events
 * 
*/


// check if section inview has class active 

window.addEventListener("scroll", function classActive(){
    for(section of sections){
        if(sectionInView(section) ){
            if(!section.classList.contains('your-active-class')){
                section.classList.add("your-active-class");
                // console.log(section.id + "doesnt have active class");
            }
            // console.log(section.id + "is in view");
        }else{
            section.classList.remove("your-active-class");
            console.log("remove")
        }

    }
  
}
);
