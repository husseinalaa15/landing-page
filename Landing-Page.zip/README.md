# Landing Page 

**Version 1.0.0**

a simple project of landing page using Javasrcipt 
created dynamic menu and scroll to each one of it using onlye vanilla javascript 
--- 
## Contributors 
- Hussein Alaa <hussein.alaa12199@gmail.com>
- udacity 
---

## License & copyright 

© Hussein alaa 